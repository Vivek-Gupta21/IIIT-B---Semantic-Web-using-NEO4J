var express = require('express');
var path = require('path');
var logger = require('morgan');
var bodyParser = require('body-parser');
var neo4j = require('neo4j-driver').v1;

var app = express();

// View engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

var driver = neo4j.driver('bolt://localhost', neo4j.auth.basic('neo4j', 'vsui738#'));
var session = driver.session();

app.get('/', function(req, res){
					res.render('index');
});

app.get('/students',function(req,res){
	session
	.run('MATCH(n:ns0__Student) RETURN n')
		.then(function(result){
			var studArr = [];
			result.records.forEach(function(record){
				studArr.push({
					id: record._fields[0].properties.ns0__student_id,
					name: record._fields[0].properties.ns0__full_name,
					gender: record._fields[0].properties.ns0__Gender,
					cgpa: record._fields[0].properties.ns0__CGPA
				});
			});
			res.render('students',{students: studArr,});
		})
		.catch(function(err) {
			console.log(err);
		});
});

app.get('/courses',function(req,res){
	session
		.run('MATCH (n:ns0__Subjects) RETURN n')
			.then(function(result2){
				var SubjectArr = [];
				result2.records.forEach(function(record){
					SubjectArr.push({
							Subject_Name: record._fields[0].properties.ns0__Subject_Name,
							Subject_Credit: record._fields[0].properties.ns0__Subject_Credits
						});
					});
					res.render('courses', {
						Subjects: SubjectArr
					});
				})
			.catch(function(err){
				console.log(err);
			});
});


app.get('/faculty',function(req,res){
	session
		.run('MATCH (n:ns0__Faculty) RETURN n')
			.then(function(result3){
				var faculty_Arr = [];
				result3.records.forEach(function(record){
					faculty_Arr.push({
						id: record._fields[0].properties.ns0__Faculty_Id,
						name: record._fields[0].properties.ns0__full_name,
						gender: record._fields[0].properties.ns0__Gender,
					});
				});
				res.render('faculty', {
					Faculty: faculty_Arr
				});
		})
	.catch(function(err){
		console.log(err);
	});
});

app.get('/inverse',function(req,res){
	res.render('inverse');
});

app.get('/symmetric',function(req,res){
	res.render('symmetric');
});

app.get('/transitive',function(req,res){
	res.render('transitive');
});

app.get('/functional',function(req,res){
	res.render('functional');
});


/*
app.get('/reflexive',function(req,res){
	res.render('reflexive');
});
*/



app.post('/student/add', function(req, res){
	var roll_no = req.body.roll_no;
	var name = req.body.stu_name;
	var gender = req.body.stu_gender;
	var cgpa = req.body.cgpa;

	session

		.run('CREATE(n:ns0__Student {ns0__student_id:{rollNoParam},ns0__full_name:{nameParam},ns0__Gender:{genderParam},ns0__CGPA:{cgpaParam}}) RETURN n.ns0__student_id', {rollNoParam:roll_no, nameParam:name, genderParam:gender, cgpaParam:cgpa})
		.then(function(result){
			res.redirect('/students'); 

			session.close();
		})
		.catch(function(err){
			console.log(err);
		});

	res.redirect('/students');
});

app.post('/subject/add', function(req, res){
	var SubjectName = req.body.Subject_Name;
	var Credits = req.body.Subject_Credit;

	session
		.run('CREATE(n:ns0__Subjects {ns0__Subject_Name:{SubjectNameParam},ns0__Subject_Credits:{CreditsParam}}) RETURN n.ns0__Subjects', {SubjectNameParam:SubjectName, CreditsParam:Credits})
		.then(function(result){
			res.redirect('/courses'); 

			session.close();
		})
		.catch(function(err){
			console.log(err);
		});

	res.redirect('/courses');
});

app.post('/faculty/add', function(req,res){
	var fac_id = req.body.fac_id;
	var fac_name = req.body.fac_name;
	var fac_gender = req.body.fac_gender;

	session
		.run('CREATE (n:ns0__Faculty{m:ns0__Faculty_Id: {fac_id_param}, f:ns0__full_name:{fac_name_param}, w:ns0__Gender: {fac_gender_param}}) RETURN n', {fac_id_param: fac_id, fac_name_param:fac_name, fac_gender_param:fac_gender})
		.then(function(result){
			res.redirect('/faculty');
			session.close();
		})
		.catch(function(err){
			console.log(err);
		});
	res.redirect('/faculty');
});



app.listen(3000);
console.log('server started on port no. 3000');

module.exports = app;
